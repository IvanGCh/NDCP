function f_PriorDC(hObject, eventdata, handles)
% f_PriorDC:    selection of previous GF to make FTAN. As the initial GF,
%               read and get headers information to obtain inter-station
%               distance, cut signal (if it is a cross-correlogram), and
%               perform FTAN.
%               At the end, on the visualization step, user can select
%               which part of the FG will be picked (causal or non-causal).

    nsac= evalin('base', 'nsac');
    kreg= evalin('base', 'kreg');
    maxlag= evalin('base', 'maxlag');
    filetype= evalin('base', 'filetype');
    
%     if kreg==1
%         kreg=nsac;
%     else
	if kreg>1
        kreg=kreg-1;
    end
    
    uicontrol('Style','text','String',[num2str(kreg) ' / ',num2str(nsac) , 'file' ],'background','w','FontSize',12,'Units','normalized','Position',[0.3 0.95 0.05 0.03])  
    
    %%
    pathsac= evalin('base', 'pathsac');
    sacfiles= evalin('base', 'sacfiles');
    namesac=[pathsac,sacfiles(kreg).name];
    trace=rdsac(namesac);
    dt=trace.HEADER.DELTA;
    lat=[trace.HEADER.STLA,trace.HEADER.EVLA];
    lon=[trace.HEADER.STLO,trace.HEADER.EVLO];
    [az,dist]=legs(lat,lon,'gc');
    dist=dist*1.852;
      
    trace=trace.d;
    if strcmp(filetype,'correlogram')==1        
        maxtime=(dt*length(trace)-dt)/2;
        time=-maxtime:dt:maxtime;           time=round(time.*1000)./1000;
        tcut = -maxlag:dt:maxlag;
        for k1=1:length(time)
            if time(k1)==tcut(1)
                ind1=round(k1);
                ind2=ind1+2*round(maxlag/dt);
            end
        end
        trace=trace(ind1:ind2);   
        trace=f_Taper(trace,0.005);      
        time=time(ind1:ind2);
    
    elseif strcmp(filetype,'seismic_record')==1        
        maxlag=length(trace)*dt;
        time=dt:dt:maxlag;
        time=round(time.*1000)./1000;
    end
    
    subplot(3,4,[3,7]),cla
	subplot(3,4,[4,8]),cla
    
    subplot(3,4,9:10),hold off
    plot(time,trace,'k'),axis([min(time) max(time) -max(abs(trace)) max(abs(trace))])
    namesacfile=sacfiles(kreg).name;
    for kchar=1:length(namesacfile)
        if strcmp(namesacfile(kchar),'_')==1
            namesacfile(kchar)=' ';
        end
    end
    title(['\bf FILE`S NAME: ',char(namesacfile), ],'fontsize',18)
    
    %%
    Tmin= evalin('base', 'Tmin');
    Tmax= evalin('base', 'Tmax');    
    filt= evalin('base', 'filt');
    fstep= evalin('base', 'fstep');
    width= evalin('base', 'width');
    filterorder= evalin('base', 'filterorder');
    [FTAN,ENV,fcm]    =   f_FTAN_Env(trace,dt,1/Tmax,1/Tmin,filt,fstep,width,filterorder);
    T=1./fcm;   T=T(length(T):-1:1);
    
    if strcmp(filetype,'correlogram')==1    
        f_Disp4PickCD_corr(time,fcm,T,FTAN,ENV,trace,dist,dt,maxlag);
        uicontrol('Style','text','String',' PART OF CC TO PICK ','background','w','FontSize',12,'Units','normalized','Position',[0.55 0.96 0.1 0.025])  
        uicontrol('Style','popup','String', 'CAUSAL|NON-CAUSAL','Units','normalized','Position', [0.66 0.935 0.1 0.05],'Callback', @f_SelectCausal);   
        uicontrol('Style','pushbutton','String','SAVE CURVE','FontSize',10,'Callback',{@f_SaveDC},'Units', 'normalized','Position', [0.8,0.96,0.05,0.035]);
        uicontrol('Style','pushbutton','String','EXPORT ALL CURVES','FontSize',10,'Callback',{@f_ExportDC},'Units', 'normalized','Position', [0.87,0.96,0.08,0.035]);
    elseif strcmp(filetype,'seismic_record')==1
        f_Disp4PickCD_seisrec(time,fcm,T,FTAN,ENV,trace,dist,dt,maxlag);
        uicontrol('Style','pushbutton','String', ' PICK DISPERSION CURVE ','Units','normalized','Position', [0.6 0.96 0.1 0.025],'Callback', @f_PickSeisRec);   
        uicontrol('Style','pushbutton','String','SAVE CURVE','FontSize',10,'Callback',{@f_SaveDC},'Units', 'normalized','Position',[0.8,0.95,0.05,0.035]);
        uicontrol('Style','pushbutton','String','EXPORT ALL CURVES','FontSize',10,'Callback',{@f_ExportDC},'Units', 'normalized','Position',[0.87,0.95,0.08,0.035]);
    end
    
    assignin('base', 'kreg', kreg)
    assignin('base', 'trace', trace)
    assignin('base', 'dist', dist)
end