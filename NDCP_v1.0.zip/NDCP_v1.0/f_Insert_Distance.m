function f_Insert_Distance(hObject, eventdata, handles)
% f_Insert_Distance
    dist=get(hObject,'String');
    handles.edit2=dist;
    guidata(hObject,handles);
    dist=str2double(dist);
    assignin('base', 'dist', dist)
end