function znet=f_Taper(zne,perc)
% zne=STACK; perc=0.01;%% PRUEBA

znet=zne;
tapx=linspace(pi/2,3*pi/2,round(perc*(length(zne)))); % tapx=tapx';
taperf=(1+sin(tapx))/2;         
taperi=taperf(length(taperf):-1:1);
taperi=taperi'; 
taperf=taperf';

% taper=[taperi,ones(1,round((1-2*perc)*(length(zne)))),taperf];  
taper=[taperi;ones(length(zne)-length(taperf)-length(taperi),1);taperf];  

clear tapx taperf taperi
[~,ncomp]=size(zne);
for kk=1:ncomp
    znet(:,kk)=zne(:,kk).*taper;
end

% figure,plot(zne,'k'),hold on,plot(znet,'r'),grid on
end