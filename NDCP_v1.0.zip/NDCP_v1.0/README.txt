
							NDCP: Noisy Dispersion Curve Picking
				
	Suite package to pick dispersion curves of Green's Function or Surface wave Seismograms
										Version 1.0
										
INPUT FILES:
Records must be SAC files, and should be placed in the same root.
Station and Event latitude/longitude must be contained in SAC headers.

TO RUN NDCP MAIN PROGRAM:
Main program NDCP (p1_NDCP.m) should be executed.
User must select if your database is from CROSS-CORRELOGRAMS or SEISMIC RECORDS, and the corresponding folder.

DEFINING FTAN PARAMETERS:
When a file is selected, NDCP read and display its Waveform and Amplitude Spectrum.
User could change FTAN parameters pre-defined.
Once the parameters were defined, NDCP will calculate and display the FTAN analysis for each record:
- FTAN waveforms of Seismic record, at top left.
- Seismic record, at bottom left.
- Velocity-Period diagram, at bottom right.
- FTAN envelopes for picking dispersion curves, at top right.

PICKING DISPERSION CURVES:
Option PICK-CURVE allow to pick the dispersion in the FTAN envelopes (top right box); to pick, you must click and hold the cursor through the dispersion waveform, then release.
When you pick some curve, you must click on SAVE CURVE to keep it on workspace.
Press PREVIOUS and NEXT button to change waveform to analyse.

EXPORTING PICKED CURVES:
Once all curves were picked and saved, button EXPORT ALL CURVES will write a 4-column ASCII files:
	1st  col. 	Frequency [Hz]
	2nd. col. 	Period [s]
	3rd. col.	Velocity [km/s]
	4th. col. 	Picked time [s]


	
	
To cite NDCP:
Granados, I., Cal�, M., and Ramos, V. (2018). NOISY DISPERSION CURVE PICKING (NDCP): a Matlab package for fully controlled seismic surface wave picking. 
Submitted to "Computer and Geosciences".

Comments, criticism and random remarks may be sent to IGranadosC@igeofisica.unam.mx

