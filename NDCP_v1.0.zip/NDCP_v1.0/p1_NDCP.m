%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%  NDCP: Noisy Dispersion Curve Picking                                 %%%
%%%  Suite package to pick velocity group dispersion curves of surface    %%%
%%%  wavesfrom noise cross correlation data and earthquakes,  Version 1.0 %%%
%%%                                                                       %%%
%%%        Copyright of Ivan Granados Chavarr�a                           %%%
%%%        Instituto de Geof�sica, UNAM, UNIVERSITY OF MEXICO             %%%
%%%        Circuito de la Investigaci�n Cient�fica s/n                    %%%
%%%        Ciudad Universitaria, Delegaci�n Coyoac�n, 04510, M�xico D.F.  %%%
%%%        email : igranadosc@igeofisica.unam.mx                          %%%
%%%                                                                       %%%
%%%        NDCP can be downloaded from:                                   %%%
%%%        https://github.com/IvanGCh/NDCP                                %%%
%%%                                                                       %%%
%%%    This code is only for research and teaching proposes. If you plan  %%%
%%%    to use it for business purposes please contact the author.         %%%
%%%                                                                       %%%
%%%                                                                       %%%
%%%    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,    %%%
%%%    EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES    %%%
%%%    OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND           %%%
%%%    NON-INFRINGEMENT. IN NO EVENT SHALL THE AUTHORS BE LIABLE          %%%
%%%    FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION    %%%
%%%    OF CONTRACT, TORT OR OTHERWISE,ARISING FROM, OUT OF OR IN          %%%
%%%    CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS          %%%
%%%    IN THE SOFTWARE.                                                   %%%
%%%                                                                       %%%
%%%                                                                       %%%
%%%        If you use this code, or parts of it, please cite:             %%%
%%%                                                                       %%%
%%%   Granados, I., Cal�, M., and Ramos, V. (2018). NOISY DISPERSION     %%%
%%%   CURVE PICKING (NDCP): a Matlab package for group velocity           %%%
%%%   dispersion picking of seismic surface waves.                        %%%
%%%   Submitted to "Computer and Geosciences".                            %%%
%%%                                                                       %%%
%%%                                                                       %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




%%%%%%%%%%%%%%%%%%%          p1_NDCP: MAIN PROGRAM          %%%%%%%%%%%%%%%%%
clear all; close all; warning('off'); clc
load ColorRB

%% Input 'GREEN'S FUNCTION FILE' & Stations list file
% Initial window for signal selection to be processed. It will take all 
% SAC-files contained in the selected folder.
%       [Opt.1 CROSS-CORRELOGRAM]       [Opt.2 SEISMIC-RECORD]
figure
set(gcf,'color',[1,1,1],'Units','normalized','Units','normalized','Position',[0.2,0.35,0.6,0.4])
uicontrol('Style','text',      'Units','normalized','Position',[0.03 0.85 0.27 0.1],'String',' SELECT TYPE OF DATA TO ANALYZE:','FontSize',12)
uicontrol('Style','pushbutton','Units','normalized','Position',[0.35 0.85 0.2 0.1],'String','CROSS-CORRELOGRAM','FontSize',12,'Callback', {@f_OPEN_CORRELOGRAM} );      
uicontrol('Style','pushbutton','Units','normalized','Position',[0.6 0.85 0.2 0.1],'String','SEISMIC RECORD','FontSize',12,'Callback', {@f_OPEN_SEISMIC_RECORD} );
uicontrol('Style','pushbutton','Units','normalized','Position',[0.85 0.85 0.12 0.1],'String','CONTINUE','FontSize',12,'Callback','uiresume(gcbf)');
uiwait(gcf);  
close

% After selection of a file in certain folder, NDCP will read all the files
% contained here.
sacfiles=dir([pathsac,'*.sac']);
nsac=length(sacfiles);    
figure,set(gcf,'color',[1,1,1]),set (gcf, 'Units','normalized','Units','normalized','Position',[0.45,0.5,0.2,0.05])
uicontrol('Style','text','Units','normalized','Position',[0.1 0.1 0.8 0.8],'String',[num2str(nsac),' Signals readed'],'FontSize',16)
pause(0.5)
close

%% TYPE OF FILTER TO USE AT FTAN STAGE
% Variable 'filt' is designed to use one of the three types of filters
% available and described in GRANADOS et al., 2018.
%   [Opt.1 PROGRAMMED]              (Default)
%   [Opt.2 BUTTER+FILTFILT] 
%   [Opt.3 DESIGNFILT+FILTFILT]
filt=1;

%% INTERSTATION/EPICENTRAL DISTANCE   
figure,set (gcf,'color',[1,1,1])
set (gcf, 'Units', 'normalized', 'Position', [0.15,0.2,0.6,0.6])

% Once the SAC file selected is read, headers containing STATION-EVENT
% location will be used to calculate DISTANCE for the proposal definition
% of FTAN parameters.
if strcmp(filetype,'correlogram')==1    
    uicontrol('Style','text','String',' CROSS-CORRELOGRAM RECORD ','FontSize',12,'Units','normalized','Position',[0.05,0.95,0.25,0.035])  
    uicontrol('Style','text','String',' Cut Signal ','background','w','FontSize',12,'Units','normalized','Position',[0.05,0.5,0.1,0.035])  
    uicontrol('Style','edit','FontSize',10,'Callback', {@f_Cut_signal},'Units','normalized','Position',[0.16,0.5,0.08,0.035]);        
elseif strcmp(filetype,'seismic_record')==1    
    uicontrol('Style','text','String',' SEISMIC RECORD ','FontSize',12,'Units','normalized','Position',[0.05,0.95,0.25,0.035])          
end

uicontrol('Style','text','String',' Distance [km] ','background','w','FontSize',12,'Units','normalized','Position',[0.05,0.9,0.1,0.035]) 
if exist('dist','var')==1
    uicontrol('Style','edit','FontSize',10,'String',num2str(dist),'Callback',{@f_Insert_Distance},'Units','normalized','Position',[0.16,0.9,0.08,0.035]);
else
    uicontrol('Style','edit','FontSize',10,'Callback',{@f_Insert_Distance},'Units','normalized','Position',[0.16,0.9,0.08,0.035]);
end

% Visualization of selected file TRACE and AMPLITUDE SPECTRUM.
axes('Position',[0.08,0.09,0.89,0.3])
plot(time,trace./max(abs(trace)),'k')
xlim([min(time) max(time)]),xlabel('\bf TIME [s]'),ylabel('\bf NORMALIZED AMPLITUDE')

subplot(2,3,2:3),   [SPEtrace,freq]=f_Spectrum(trace,dt);
loglog(freq,abs(SPEtrace),'k'),hold on
xlim([min(freq) max(freq)]),xlabel('\bf FREQUENCY [Hz]')
    
%% FTAN PARAMETERS
% At each interstation/epicentral distance, NDCP proposes some
% parameters empircially optimized for the FTAN. User can test different vaules to
% ensure the best emergence of the Surface wave dispersion pattern.
if      dist<15
    defFTAN=[0.2,4,0.025,0.07,8];
    minvel=0.1;
    maxvel=2.0;
elseif  dist>=15 && dist<80 
    defFTAN=[0.5,10,0.025,0.07,8];
    minvel=0.1;
    maxvel=3.5;
elseif  dist>=80 && dist<150 
    defFTAN=[1,25,0.025,0.07,8];
    minvel=0.5;
    maxvel=4.5;
elseif  dist>150
    defFTAN=[3,80,0.025,0.07,8];
    minvel=1;
    maxvel=6;
end

uicontrol('Style','text','String',' FTAN PARAMETERS ','FontSize',12,'Units','normalized','Position',[0.05,0.8,0.25,0.035])  
uicontrol('Style','text','String',' T min [s] ','background','w','FontSize',12,'Units','normalized','Position',[0.05,0.75,0.1,0.035])  
uicontrol('Style','edit','FontSize',10,'String',num2str(defFTAN(1)),'Callback',{@f_Insert_Tmin},'Units','normalized','Position',[0.16,0.75,0.08,0.035]);

uicontrol('Style','text','String',' T max [s] ','background','w','FontSize',12,'Units','normalized','Position',[0.05,0.7,0.1,0.035])  
uicontrol('Style','edit','FontSize',10,'String',num2str(defFTAN(2)),'Callback', {@f_Insert_Tmax},'Units','normalized','Position',[0.16,0.7,0.08,0.035]);        

uicontrol('Style','text','String',' fstep ','background','w','FontSize',12,'Units','normalized','Position',[0.05,0.65,0.1,0.035])  
uicontrol('Style','edit','FontSize',10,'String',num2str(defFTAN(3)),'Callback', {@f_Insert_fstep},'Units','normalized','Position',[0.16,0.65,0.08,0.035] );        

uicontrol('Style','text','String',' width ','background','w','FontSize',12,'Units','normalized','Position',[0.05,0.6,0.1,0.035])  
uicontrol('Style','edit','FontSize',10,'String',num2str(defFTAN(4)),'Callback', {@f_Insert_width},'Units','normalized','Position',[0.16,0.6,0.08,0.035]);        

uicontrol('Style','text','String',' Filter order ','background','w','FontSize',12,'Units','normalized','Position',[0.05,0.55,0.1,0.035])  
uicontrol('Style','edit','FontSize',10,'String',num2str(defFTAN(5)),'Callback', {@f_Insert_filterorder},'Units','normalized','Position',[0.16,0.55,0.08,0.035]);        

uicontrol('Style','text','String',' Cut Signal ','background','w','FontSize',12,'Units','normalized','Position',[0.05,0.5,0.1,0.035])  
uicontrol('Style','edit','FontSize',10,'Callback', {@f_Cut_signal},'Units','normalized','Position',[0.16,0.5,0.08,0.035]);        
    
uicontrol('Style','pushbutton','String','PROCESS','FontSize',10,'Callback','uiresume(gcbf)','Units', 'normalized','Position',[0.05,0.45,0.2,0.035]);
uiwait(gcf)
close

if  exist('Tmin')==0,           Tmin=defFTAN(1);        end
if  exist('Tmax')==0,           Tmax=defFTAN(2);        end
if  exist('fstep')==0,          fstep=defFTAN(3);       end
if  exist('width')==0,          width=defFTAN(4);       end
if  exist('filterorder')==0,    filterorder=defFTAN(5); end
if  exist('maxlagsel')==1,      maxlag=maxlagsel; end

%%
fig_princ=figure(1);
set(gcf,'color',[1,1,1])
set (gcf, 'Units','normalized','Units','normalized','Position',[0,0.04,1,0.88])

% READ and DISPLAY of selected SAC files in correspondingly folder.
% in this step the user can select Prior or Next file to visualize:
%   - TRACE of the Cross-correlogram or seismic record (left bottom)
%   - Narrow-band filtered TRACES, where the dispersion phenomena could be 
%     observed.
%   - COLOR MAP of FTAN, where the user is allowed to pick dispersion curve
%           [RED: lower energy]    [BLUE: higher energy]
% 	- GROUP VELOCITY - PERIOD Diagram & dispersion curve (once is was picked)

kreg=1;
uicontrol('Style','pushbutton','Units','normalized','Position',[0.12 0.95 0.1 0.03],'String','PREVIOUS','Callback', {@f_PriorDC} );
uicontrol('Style','pushbutton','Units','normalized','Position',[0.4 0.95 0.1 0.03],'String','NEXT','Callback', {@f_NextDC} );       

namesac=[pathsac,sacfiles(kreg).name];
trace=rdsac(namesac);
dt=trace.HEADER.DELTA;
[az,dist]=legs([trace.HEADER.STLA,trace.HEADER.EVLA],[trace.HEADER.STLO,trace.HEADER.EVLO],'gc');
dist=dist*1.852;
trace=trace.d;

if strcmp(filetype,'correlogram')==1 
    pickedcurves=cell(nsac,2);
    maxtime=(dt*length(trace)-dt)/2;
    time=-maxtime:dt:maxtime;
    time=round(time.*1000)./1000;   
    if exist('maxlagsel')==1
        tcut = -maxlag:dt:maxlag;
        for k1=1:length(time)
            if time(k1)==tcut(1)
                ind1=round(k1);
                ind2=ind1+2*round(maxlag/dt);
            end
        end
        trace=trace(ind1:ind2);   
        time=time(ind1:ind2);  clear tcut maxtime kl   
    else
        ind1=1;
        ind2=length(trace);
    end
	trace=f_Taper(trace,0.005);   
elseif strcmp(filetype,'seismic_record')==1
    pickedcurves=cell(nsac,1);
    trace=f_Taper(trace,0.005);
    maxlag=length(trace)*dt;
    time=dt:dt:maxlag;
    time=round(time.*1000)./1000;
end

subplot(3,4,9:10),cla
plot(time,trace,'k'),axis([min(time) max(time) -max(abs(trace)) max(abs(trace))])
namesacfile=sacfiles(kreg).name;
for kchar=1:length(namesacfile)
    if strcmp(namesacfile(kchar),'_')==1
        namesacfile(kchar)=' ';
    end
end
title(['\bf FILE`S NAME: ',char(namesacfile), ],'fontsize',12)

% STEP where the FTAN process is calculated by f_FTAN_Env function.
[FTAN,ENV,fcm,fcwidth]    =   f_FTAN_Env(trace,dt,1/Tmax,1/Tmin,filt,fstep,width,filterorder);
T=1./fcm;   T=T(length(T):-1:1);    vel=dist./time;

% For each type of the file selected (CROSS-CORRELOGRAM or SEISMIC RECORD),
% this step includes VISUALIZATION of color-maps diagrams, picked curves,
% and allows the user for selecting the curve that will be saved and exported in ASCII format.
if strcmp(filetype,'correlogram')==1 
    f_Disp4PickCD_corr(time,fcm,T,FTAN,ENV,trace,dist,dt,maxlag);
    uicontrol('Style','text','String',' PART OF CC TO PICK ','background','w','FontSize',12,'Units','normalized','Position',[0.55 0.96 0.1 0.025])  
    uicontrol('Style','popup','String', 'CAUSAL|NON-CAUSAL','Units','normalized','Position', [0.66 0.935 0.1 0.05],'Callback', @f_SelectCausal);   
	uicontrol('Style','pushbutton','String','SAVE CURVE','FontSize',10,'Callback',{@f_SaveDC},'Units', 'normalized','Position', [0.8,0.96,0.05,0.035]);
    uicontrol('Style','pushbutton','String','EXPORT ALL CURVES','FontSize',10,'Callback',{@f_ExportDC},'Units', 'normalized','Position', [0.87,0.96,0.08,0.035]);
elseif strcmp(filetype,'seismic_record')==1
    f_Disp4PickCD_seisrec(time,fcm,T,FTAN,ENV,trace,dist,dt,maxlag);
    uicontrol('Style','pushbutton','String', ' PICK DISPERSION CURVE ','Units','normalized','Position', [0.6 0.96 0.1 0.025],'Callback', @f_PickSeisRec);   
	uicontrol('Style','pushbutton','String','SAVE CURVE','FontSize',10,'Callback',{@f_SaveDC},'Units', 'normalized','Position',[0.8,0.95,0.05,0.035]);
    uicontrol('Style','pushbutton','String','EXPORT ALL CURVES','FontSize',10,'Callback',{@f_ExportDC},'Units', 'normalized','Position',[0.87,0.95,0.08,0.035]);
end


